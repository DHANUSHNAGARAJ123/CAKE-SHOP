from django.apps import AppConfig

class ConsumptionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.consumption'